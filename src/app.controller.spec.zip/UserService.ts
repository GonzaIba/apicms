import { Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';


export class UserService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
  ) {}

  async callStoredProcedure(USER: string, PASS: string) {
    const result = await this.dataSource.query('CALL SP_TEST_LOGIN @0, @1', [USER,PASS] );
    return result;
  }
}