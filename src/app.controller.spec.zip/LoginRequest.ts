export class loginRequest {
    user: string;
    pass: string;
   
  }