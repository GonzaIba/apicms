import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserService } from './userservice';
import { AppController } from './app.controller';
 

@Module({
    imports: [TypeOrmModule.forRoot({
    
        type: 'mssql',
        host: 'localhost',
        username: 'sa',
        password: '123',
        database: 'TT',
        options: {
          encrypt: false, // MSSQL-specific option
        },
        synchronize: true, //use this with development environment
        entities: [],
      }),
       ]  ,
  providers: [UserService],
  controllers: [AppController],
})
export class UsersModule {}